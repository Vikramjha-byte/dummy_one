class Users{
	private int id;
	private String title,description,branch,year,almuni,date,type;
	public void User(){
		this.id=id;
		this.title=title;
		this.description=description;
		this.branch=branch;
		this.year=year;
		this.almuni=almuni;
		this.date=date;
		this.type=type;
	}
	public int getid(){return id;}
	public String gettitle(){return title;}
	public String getdescription(){return description;}
	public String getbranch(){return branch;}
	public String getyear(){return year;}
	public String getalmuni(){return almuni;}
	public String getdate(){return date;}
	public String gettype(){return type;}
}