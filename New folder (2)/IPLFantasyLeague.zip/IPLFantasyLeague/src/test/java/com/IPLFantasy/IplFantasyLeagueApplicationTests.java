package com.IPLFantasy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IplFantasyLeagueApplicationTests {

	@Test
	void contextLoads() {
	}

}
